package drama.painter.web.mall.controller;

import drama.painter.web.mall.service.inf.IChat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author murphy
 */
@Controller
public class UserController {
	final IChat staff;

	public UserController(IChat staff) {
		this.staff = staff;
	}

	@GetMapping("/login/login")
	public String login() {
		return "login/login";
	}
}
