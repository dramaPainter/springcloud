package drama.painter.web.mall.service.pay.anomaly;

/**
 * @author murphy
 */
public class SignMismatchException extends RuntimeException {
	public SignMismatchException(String msg) {
		super(msg);
	}
}
