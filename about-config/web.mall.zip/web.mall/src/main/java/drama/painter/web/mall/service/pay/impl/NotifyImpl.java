package drama.painter.web.mall.service.pay.impl;

import drama.painter.web.mall.service.pay.interfaces.INotify;
import org.springframework.stereotype.Service;

/**
 * @author murphy
 */
@Service
public class NotifyImpl implements INotify {
	@Override
	public void notifyMail(int userid) {

	}
}
