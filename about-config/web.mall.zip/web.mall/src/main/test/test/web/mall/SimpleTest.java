package test.web.mall;

import drama.painter.core.web.utility.Encrypts;
import drama.painter.core.web.utility.Strings;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@Slf4j
public class SimpleTest {
	@Test
	public void test() {
	}
}